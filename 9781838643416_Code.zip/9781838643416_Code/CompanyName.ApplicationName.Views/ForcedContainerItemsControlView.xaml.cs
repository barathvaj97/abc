﻿using System.Windows.Controls;

namespace CompanyName.ApplicationName.Views
{
    /// <summary>
    /// Interaction logic for ForcedContainerItemsControlView.xaml
    /// </summary>
    public partial class ForcedContainerItemsControlView : UserControl
    {
        /// <summary>
        /// Initializes a new ForcedContainerItemsControlView object.
        /// </summary>
        public ForcedContainerItemsControlView()
        {
            InitializeComponent();
        }
    }
}