﻿using System.Windows.Controls;

namespace CompanyName.ApplicationName.Views
{
    /// <summary>
    /// Demonstrates how to use the validatation error template.
    /// </summary>
    public partial class ErrorTemplateView : UserControl
    {
        /// <summary>
        /// Initializes a new ErrorTemplateView object.
        /// </summary>
        public ErrorTemplateView()
        {
            InitializeComponent();
        }
    }
}