﻿using System.Windows.Controls;

namespace CompanyName.ApplicationName.Views
{
    /// <summary>
    /// Interaction logic for AnimatedPanelView.xaml
    /// </summary>
    public partial class AnimatedPanelView : UserControl
    {
        /// <summary>
        /// Initializes a new AnimatedPanelView object.
        /// </summary>
        public AnimatedPanelView()
        {
            InitializeComponent();
        }
    }
}