﻿using System.Windows.Controls;

namespace CompanyName.ApplicationName.Views
{
    /// <summary>
    /// Interaction logic for EasingAnimationView.xaml
    /// </summary>
    public partial class EasingAnimationView : UserControl
    {
        /// <summary>
        /// Initializes a new EasingAnimationView object.
        /// </summary>
        public EasingAnimationView()
        {
            InitializeComponent();
        }
    }
}