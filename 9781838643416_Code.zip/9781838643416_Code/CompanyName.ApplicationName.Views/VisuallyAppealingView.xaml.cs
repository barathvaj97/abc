﻿using System.Windows.Controls;

namespace CompanyName.ApplicationName.Views
{
    /// <summary>
    /// Interaction logic for VisuallyAppealingView.xaml
    /// </summary>
    public partial class VisuallyAppealingView : UserControl
    {
        /// <summary>
        /// Initializes a new VisuallyAppealingView object.
        /// </summary>
        public VisuallyAppealingView()
        {
            InitializeComponent();
        }
    }
}