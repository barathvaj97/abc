﻿using System.Windows.Controls;

namespace CompanyName.ApplicationName.Views
{
    /// <summary>
    /// Interaction logic for AnimationView.xaml
    /// </summary>
    public partial class AnimationView : UserControl
    {
        /// <summary>
        /// Initializes a new AnimationView object.
        /// </summary>
        public AnimationView()
        {
            InitializeComponent();
        }
    }
}