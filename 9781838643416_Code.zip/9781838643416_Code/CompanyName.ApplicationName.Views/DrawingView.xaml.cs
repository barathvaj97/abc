﻿using System.Windows.Controls;

namespace CompanyName.ApplicationName.Views
{
    /// <summary>
    /// Interaction logic for DrawingView.xaml
    /// </summary>
    public partial class DrawingView : UserControl
    {
        /// <summary>
        /// Initializes a new DrawingView object.
        /// </summary>
        public DrawingView()
        {
            InitializeComponent();
        }
    }
}