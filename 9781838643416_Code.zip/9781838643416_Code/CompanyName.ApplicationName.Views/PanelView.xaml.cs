﻿using System.Windows.Controls;

namespace CompanyName.ApplicationName.Views
{
    /// <summary>
    /// Interaction logic for PanelView.xaml
    /// </summary>
    public partial class PanelView : UserControl
    {
        /// <summary>
        /// Initializes a new PanelView object.
        /// </summary>
        public PanelView()
        {
            InitializeComponent();
        }
    }
}