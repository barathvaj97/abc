﻿using System.Windows.Controls;

namespace CompanyName.ApplicationName.Views
{
    /// <summary>
    /// Interaction logic for MeterView.xaml
    /// </summary>
    public partial class MeterView : UserControl
    {
        /// <summary>
        /// Initializes a new MeterView object.
        /// </summary>
        public MeterView()
        {
            InitializeComponent();
        }
    }
}